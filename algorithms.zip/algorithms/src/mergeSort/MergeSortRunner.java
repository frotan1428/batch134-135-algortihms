package mergeSort;



import java.util.Arrays;
import java.util.Random;

public class MergeSortRunner {
    public static void main(String[] args) {
        Random random = new Random();
        int [] numberList = new int[100000000];
        for (int i=0; i<numberList.length; i++){
            numberList[i] = random.nextInt(100000);
        }

        int [] arr = {9, 7, 6,15, 17, 5, 10, 11};

        System.out.println("********** Before Merge Sort **********");
        System.out.println(Arrays.toString(numberList));
        System.out.println("********** After Merge Sort **********");
        MergeSort.mergeSort(numberList);
        System.out.println(Arrays.toString(numberList));
    }
}
