import bubbleSort.BubbleSort;
import insertionSort.InsertionSort;
import mergeSort.MergeSort;
import quickSort.QuickSort;
import selectionSort.SelectionSort;
import shellSort.ShellSort;

import java.util.Arrays;
import java.util.Random;

public class CompareAlgorithms {
    public static void main(String[] args) {

        int [] orderedArray = createOrderedArray(100000);

        int [] unOrderedArray = createRandomArray(100000);
        int[] unOrderedArray1 = Arrays.copyOf(unOrderedArray, unOrderedArray.length);
        int[] unOrderedArray2 = Arrays.copyOf(unOrderedArray, unOrderedArray.length);
        int[] unOrderedArray3 = Arrays.copyOf(unOrderedArray, unOrderedArray.length);
        int[] unOrderedArray4 = Arrays.copyOf(unOrderedArray, unOrderedArray.length);
        int[] unOrderedArray5 = Arrays.copyOf(unOrderedArray, unOrderedArray.length);
        int[] unOrderedArray6 = Arrays.copyOf(unOrderedArray, unOrderedArray.length);
        int[] unOrderedArray7 = Arrays.copyOf(unOrderedArray, unOrderedArray.length);

        long startTime;
        long endTime;
        double estimatedTime;

        //insertionSort
        startTime = System.currentTimeMillis();
//        InsertionSort.insertionSort(unOrderedArray1);
        InsertionSort.insertionSort(orderedArray);
        endTime = System.currentTimeMillis();
        estimatedTime = (double) (endTime-startTime)/1000;
        System.out.println("Insertion Sort: "+estimatedTime);

        //selection sort
        startTime = System.currentTimeMillis();
//        SelectionSort.selectionSort(unOrderedArray2);
        SelectionSort.selectionSort(orderedArray);
        endTime = System.currentTimeMillis();
        estimatedTime = (double) (endTime-startTime)/1000;
        System.out.println("Selection Sort: "+estimatedTime);

        //bubble sort
        startTime = System.currentTimeMillis();
//        BubbleSort.bubbleSort(unOrderedArray3);
        BubbleSort.bubbleSort(orderedArray);
        endTime = System.currentTimeMillis();
        estimatedTime = (double) (endTime-startTime)/1000;
        System.out.println("Bubble Sort: "+estimatedTime);

        //quick sort
        startTime = System.currentTimeMillis();
      //  QuickSort.quickSort(unOrderedArray4, 0, unOrderedArray4.length-1);
        QuickSort.quickSort(orderedArray, 0, orderedArray.length-1);
        endTime = System.currentTimeMillis();
        estimatedTime = (double) (endTime-startTime)/1000;
        System.out.println("Quick Sort: "+estimatedTime);

        //merge sort
        startTime = System.currentTimeMillis();
//        MergeSort.mergeSort(unOrderedArray5);
        MergeSort.mergeSort(orderedArray);
        endTime = System.currentTimeMillis();
        estimatedTime = (double) (endTime-startTime)/1000;
        System.out.println("Merge Sort: "+estimatedTime);

        //Shell sort
        startTime = System.currentTimeMillis();
//        ShellSort.shellSort(unOrderedArray6);
        ShellSort.shellSort(orderedArray);
        endTime = System.currentTimeMillis();
        estimatedTime = (double) (endTime-startTime)/1000;
        System.out.println("Shell Sort: "+estimatedTime);

        //Arrays sort
        //bubble sort
        startTime = System.currentTimeMillis();
//        Arrays.sort(unOrderedArray7);
        Arrays.sort(orderedArray);
        endTime = System.currentTimeMillis();
        estimatedTime = (double) (endTime-startTime)/1000;
        System.out.println("Array Sort: "+estimatedTime);

    }

    //method to create array with random numbers
    public static int [] createRandomArray(int numOfElements){
        Random random = new Random();
        int[] numberList = new int[numOfElements];
        for(int i = 0; i<numberList.length; i++){
            numberList[i] = random.nextInt(10000);
        }
        return numberList;
    }
    //method to create array with sorted elements
    public static int[] createOrderedArray(int numOfElements){
        int[] numberList = new int[numOfElements];
        for(int i = 0; i<numberList.length; i++){
            numberList[i] = i;
        }
        return numberList;
    }

}
