package quickSort;


import java.util.Arrays;
import java.util.Random;

public class QuickSortRunner {
    public static void main(String[] args) {

        Random random = new Random();
        int [] numberList = new int[100000000];
        for (int i=0; i<numberList.length; i++){
            numberList[i] = random.nextInt(100000);
        }

        int [] arr = {9, 7, 6,15, 17, 5, 10, 11};

        System.out.println("********** Before Quick Sort **********");
        System.out.println(Arrays.toString(numberList));
        System.out.println("********** After Quick Sort **********");
        QuickSort.quickSort(numberList, 0, numberList.length-1);
        System.out.println(Arrays.toString(numberList));
    }
}
