package quickSort;

public class QuickSort {

    public static void quickSort(int [] arr, int lowIndex, int highIndex){
        //if there is one element in subarray, it needs to return
        if(lowIndex>=highIndex){
            return;
        }

        //define pivot
        int pivot = arr[highIndex];

        //define two pointers
        int lefPointer = lowIndex;
        int rightPointer = highIndex;

        //
        while (lefPointer<rightPointer){
            //movint leftPointer to right
            while (arr[lefPointer]<=pivot && lefPointer<rightPointer){
                lefPointer++;
            }
            while (arr[rightPointer]>=pivot && lefPointer<rightPointer){
                rightPointer --;
            }
            //swapping elements which are pointed by leftPointer and rightPointer
            swap(arr, lefPointer, rightPointer );

        }
        //swapping elements which are pointed leftPointer and pivot
        swap(arr, lefPointer, highIndex);

        //we are doing partioning for the subarray which is left side of pivot point
        quickSort(arr, lowIndex, lefPointer-1);
        //we are doing partioning for the subarray which is right side of pivot point
        quickSort(arr, lefPointer+1, highIndex);
    }
    // method to swap
    private static void swap(int[] array, int index1, int index2){
        int temp = array[index1];
        array[index1] = array[index2];
        array[index2] = temp;
    }

}
