package bigO;

public class BigOn {
    public static void main(String[] args) {
        //print element of array
        int [] arr = {3,5, 6, 1};
        for(int i:arr){
            System.out.println(i);
        }
    }
}
