package shellSort;

import mergeSort.MergeSort;

import java.util.Arrays;
import java.util.Random;

public class ShellSortRunner {
    public static void main(String[] args) {
        Random random = new Random();
        int [] numberList = new int[100000000];
        for (int i=0; i<numberList.length; i++){
            numberList[i] = random.nextInt(100000);
        }

        int [] arr = {9, 7, 6,15, 17, 5, 10, 11};

        System.out.println("********** Before Shell Sort **********");
        System.out.println(Arrays.toString(arr));
        System.out.println("********** After Shell Sort **********");
        ShellSort.shellSort(arr);
        System.out.println(Arrays.toString(arr));
    }
}
